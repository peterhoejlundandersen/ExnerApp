/**
 * Copyright (c) Tiny Technologies, Inc. All rights reserved.
 * Licensed under the LGPL or a commercial license.
 * For LGPL see License.txt in the project root for license information.
 * For commercial licenses see https://www.tiny.cloud/
 *
 * Version: 5.0.12 (2019-07-18)
 */

!function(){"use strict";var n=tinymce.util.Tools.resolve("tinymce.PluginManager"),t=tinymce.util.Tools.resolve("tinymce.dom.DOMUtils"),o=tinymce.util.Tools.resolve("tinymce.util.Tools"),a=function(n){return n.getParam("save_enablewhendirty",!0)},i=function(n){return!!n.getParam("save_onsavecallback")},c=function(n){return!!n.getParam("save_oncancelcallback")},r=function(n,e){n.notificationManager.open({text:e,type:"error"})},e=function(n){var e;if(e=t.DOM.getParent(n.id,"form"),!a(n)||n.isDirty()){if(n.save(),i(n))return n.execCallback("save_onsavecallback",n),void n.nodeChanged();e?(n.setDirty(!1),e.onsubmit&&!e.onsubmit()||("function"==typeof e.submit?e.submit():r(n,"Error: Form submit field collision.")),n.nodeChanged()):r(n,"Error: No form element found.")}},u=function(n){var e=o.trim(n.startContent);c(n)?n.execCallback("save_oncancelcallback",n):n.resetContent(e)},l=function(n){n.addCommand("mceSave",function(){e(n)}),n.addCommand("mceCancel",function(){u(n)})},s=function(t){return function(n){var e=function(){n.setDisabled(a(t)&&!t.isDirty())};return t.on("NodeChange dirty",e),function(){return t.off("NodeChange dirty",e)}}},d=function(n){n.ui.registry.addButton("save",{icon:"save",tooltip:"Save",disabled:!0,onAction:function(){return n.execCommand("mceSave")},onSetup:s(n)}),n.ui.registry.addButton("cancel",{icon:"cancel",tooltip:"Cancel",disabled:!0,onAction:function(){return n.execCommand("mceCancel")},onSetup:s(n)}),n.addShortcut("Meta+S","","mceSave")};!function m(){n.add("save",function(n){d(n),l(n)})}()}();
